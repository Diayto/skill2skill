import { useMemo, useState } from "react";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import UserCard from "../components/UserCard";
import { getUsers } from "../lib/storage";

export default function Home(){
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const users = getUsers();

  const filtered = useMemo(()=>{
    const s = q.trim().toLowerCase();
    if(!s) return users;
    return users.filter(u =>
      (u.email||"").toLowerCase().includes(s) ||
      (u.bio||"").toLowerCase().includes(s) ||
      (u.offers||[]).join(",").toLowerCase().includes(s) ||
      (u.wants||[]).join(",").toLowerCase().includes(s)
    );
  }, [users, q]);

  return (
    <>
      <Navbar search={q} onSearch={setQ} onToggleSidebar={()=>setOpen(v=>!v)} />
      <Sidebar open={open} onClose={()=>setOpen(false)} />

      <div className="container" style={{paddingTop:96, display:'grid', gap:16}}>
        {filtered.length === 0
          ? <div className="card">Пока никого нет. Создай аккаунт на странице регистрации.</div>
          : <div className="grid">{filtered.map((u,i)=> <UserCard key={u.email+i} user={u}/>)}</div>
        }
      </div>
    </>
  );
}
