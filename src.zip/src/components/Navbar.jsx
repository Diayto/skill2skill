import { Link } from "react-router-dom";
import logo from "../assets/skill2s.png";

export default function Navbar({ search, onSearch, onToggleSidebar }) {
  return (
    <header className="navbar">
      <button className="burger" onClick={onToggleSidebar} aria-label="Меню">☰</button>

      {/* только иконка */}
      <Link to="/home" className="brand-slot" aria-label="Skill2Skill">
        <img className="brand-mark" src={logo} alt="Skill2Skill" draggable="false" />
      </Link>

      <input
        className="search"
        value={search}
        onChange={(e) => onSearch?.(e.target.value)}
        placeholder="Поиск людей..."
      />

      <Link to="/profile" className="btn btn-primary profile-btn">Профиль</Link>
    </header>
  );
}
