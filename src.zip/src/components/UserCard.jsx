import { Link } from "react-router-dom";
import { getAverageRating } from "../lib/storage";

function StarsDisplay({value}){
  const full = Math.round(value);
  return (
    <span className="stars small" aria-hidden>
      {[1,2,3,4,5].map(n=> <span key={n} className={`star ${n<=full?'filled':''}`}>★</span>)}
    </span>
  );
}

export default function UserCard({user}){
  const avg = getAverageRating(user);

  return (
    <Link to={`/profile/${encodeURIComponent(user.email)}`} className="user-card">
      {user.photo
        ? <img className="avatar-img" src={user.photo} alt="avatar"/>
        : <div className="avatar">{user.email[0]?.toUpperCase()}</div>}
      <div className="uc-body">
        <div className="uc-email">{user.email}</div>
        <div className="uc-bio">{user.bio || "Пока без описания"}</div>
        <div className="uc-tags">
          {user.offers?.length ? <span className="pill"> Учу: {user.offers.slice(0,3).join(", ")}</span> : null}
          {user.wants?.length ? <span className="pill"> Хочу: {user.wants.slice(0,3).join(", ")}</span> : null}
        </div>
        <StarsDisplay value={avg}/>
      </div>
    </Link>
  );
}
