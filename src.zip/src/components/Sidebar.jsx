import { useState } from "react";
import { Link } from "react-router-dom";
import SubscriptionModal from "./SubscriptionModal";

export default function Sidebar({ open, onClose }) {
  const [subOpen, setSubOpen] = useState(false);

  return (
    <>
      {open && <div className="backdrop" onClick={onClose} />}

      <aside className={`sidebar ${open ? "open" : ""}`} aria-hidden={!open}>
        <nav className="side-links">
          <Link to="/home" onClick={onClose}> Главная</Link>
          <Link to="/profile" onClick={onClose}> Профиль</Link>

          {/* Подписка */}
          <button
            type="button"
            className="side-link-btn"
            onClick={() => setSubOpen(true)}
          >
             Подписка
          </button>
        </nav>
      </aside>

      <SubscriptionModal
        open={subOpen}
        onClose={() => setSubOpen(false)}
      />
    </>
  );
}
